#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import xlrd
import pandas as pd
from pandas import read_excel
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.offline as po
import plotly.graph_objs as go 
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


path = r'C:\Users\LENOVO\Downloads\KPMG_VI_New_raw_data_update_final.xlsx'
cus_demo = pd.read_excel(path, sheet_name ='CustomerDemographic');cus_demo.head();
cus_add = pd.read_excel(path, sheet_name ='CustomerAddress');cus_add.head();
New_cus_List = pd.read_excel(path, sheet_name ='NewCustomerList');New_cus_List.head();
transact = pd.read_excel(path, sheet_name ='Transactions');transact.head()


# In[5]:


# Combining and Merging sheet by concat and merging
case1 = pd.merge(cus_demo,cus_add, how='left',on='customer_id');case1
customer_data = pd.concat([case1, New_cus_List]); customer_data


# In[6]:


type(customer_data)


# In[7]:


customer_data.describe(include='all')


# In[8]:


transact.describe(include='all')


# In[9]:


customer_data.info(); transact.info()


# In[10]:


customer_data.hist(figsize=(20,30)) # plots only floats and numerical variables


# In[11]:


transact.hist(figsize=(20,30))


# In[12]:


sns.boxplot(x='gender',y='Age', data =customer_data)


# In[13]:


sns.boxplot(x='gender', y ='past_3_years_bike_related_purchases', data= customer_data)


# In[14]:


sns.boxplot(x='job_industry_category', y ='past_3_years_bike_related_purchases', data= customer_data)


# In[15]:


sns.boxplot(x='brand', y ='list_price', data= transact)


# In[16]:


pd.pivot_table(transact, index=['brand','order_status'], columns =['product_size'],aggfunc=len)


# In[17]:


sns.lmplot(y='standard_cost',x='list_price', hue="order_status", data=transact)


# In[18]:


sns.pointplot( customer_data['property_valuation'],customer_data['past_3_years_bike_related_purchases'],hue=customer_data['gender'])


# In[19]:


sns.barplot(transact['brand'], transact['list_price'], hue=transact['order_status'])


# In[20]:


customer_data.groupby('job_industry_category')['past_3_years_bike_related_purchases'].median()


# In[21]:


sns.stripplot(transact['product_size'],transact['list_price'],jitter=True)


# In[22]:


sns.stripplot(customer_data['job_industry_category'],customer_data['past_3_years_bike_related_purchases'],jitter=True)


# In[23]:


sns.distplot(customer_data['Age'])


# In[24]:


corr = customer_data.corr()
sns.heatmap(corr, annot=True)


# In[25]:


trans = transact.corr()
sns.heatmap(trans, annot=True)


# In[26]:


cov = customer_data.cov()
cov


# In[27]:


transact.hist(by ="brand", column='list_price', figsize=(20,30))


# In[28]:


sns.pairplot(customer_data)


# In[29]:


sns.pairplot(transact)


# In[30]:


# Final merging of transaction and customer_level data(case2)
final_data = pd.merge(customer_data, transact, how='left', on='customer_id'); final_data


# In[37]:


# Data Cleaning, Filling of Missing Values , treating categorical(object) and numerical values
type(final_data)
final_data.isnull().sum()


# In[41]:


# drop irrelevant data 
dataset = final_data.drop(['first_name', 'last_name','customer_id', 'default','DOB'], axis=1)
dataset.dtypes


# In[77]:


obj_df = dataset.select_dtypes(include=['object']).copy()
obj_df.head()


# In[72]:


obj_df.columns.values


# In[51]:


int_df = dataset.select_dtypes(include=['int64']).copy()
float_df=dataset.select_dtypes(include=['float64']).copy()
df_int_float = pd.concat([float_df,int_df], axis=1)
df_int_float.columns.values


# In[ ]:





# In[82]:





# In[83]:


correlation_matrix = np.corrcoef(df_dummies.T)
print(correlation_matrix)


# In[ ]:




