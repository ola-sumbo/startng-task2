import pandas as pd
import numpy as np
from pandas import Series, DataFrame
import xlrd
import matplotlib.pyplot as plt

excel_file = 'C:\Users\sumbo\Documents\TakenMind-Python-Analytics-Problem-case-study-1-1.xlsx'
# Ingest the data
a1 = pd.read_excel(excel_file, sheet_name='Existing employees')
a2 = pd.read_excel(excel_file, sheet_name='Employees who have left')

all_in_one = [a1, a2]

append_attr = pd.concat(all_in_one)

append_attr.to_excel("attr.xlsx", index=False)

data = pd.read_excel(r'attr.xlsx')
print data.columns.values


col_names = data.columns.tolist()
print("Column names:")
print(col_names)

print("\nSample data:")
data.head()

filter = (data['salary'] == 'high')
data.loc[filter, 'left'] = 1

filter = (data['salary'] == 'medium')
data.loc[filter, 'left'] = 0

filter = (data['salary'] == 'low')
data.loc[filter, 'left'] = 0

#print data.dtypes
#print data.describe()

# Checking for missing data
#print data.isnull().any()

left = data.groupby('left')
print left.mean()


# DATA EXPLORATION
# unique values for categorical values
print data['dept'].unique()
print data['left'].value_counts()

print data.groupby('dept').mean()
print data.groupby('salary').mean()

#Bar chart for dept agaiinst the freuency of pple left
pd.crosstab(data.dept,data.left).plot(kind='barh')
plt.title('Frequency for Department')
plt.xlabel('Department')
plt.ylabel('Frequency of people who left')
plt.savefig('dept_bar_chart')
plt.show()

import seaborn as sns
features=['number_project','time_spend_company','Work_accident','left', 'promotion_last_5years','dept','salary']
#fig=plt.subplots(figsize=(10,15))
#for i, j in enumerate(features):
    #plt.subplot(4, 2, i+1)
    #plt.subplots_adjust(hspace = 1.0)
    #sns.countplot(x=j,data = data)
    #plt.xticks(rotation=90)
    #plt.title("Count of features on employees")
#plt.show()

fig=plt.subplots(figsize=(10,15))
for i, j in enumerate(features):
    plt.subplot(4, 2, i+1)
    plt.subplots_adjust(hspace = 1.0)
    sns.countplot(x=j,data = data, hue='left')
    plt.xticks(rotation=90)
    plt.title("Count of employees who left")
plt.show()

import statsmodels.api as sm
#Corr = data.corr()
#sm.graphics.plot_corr(Corr, xnames=list(Corr.columns))
#plt.show()

#Histogram of numeric variables
#num_bins = 10
#data.hist(bins=num_bins, figsize=(20,15))
#plt.savefig("data_frequency_histplot")
#plt.show()


#import module
from sklearn.cluster import KMeans
# extract data
emp_who_left =  data[['satisfaction_level', 'last_evaluation']][data.left == 1]
# make groups for K-means clustering.
kmeans = KMeans(n_clusters = 3, random_state = 0).fit(emp_who_left)
# input a new column "label" annd assign cluster labels.
emp_who_left['label'] = kmeans.labels_
# Draw scatter plot
plt.scatter(emp_who_left['satisfaction_level'], emp_who_left['last_evaluation'], c=emp_who_left['label'],cmap='Accent')
plt.xlabel('Satisfaction Level')
plt.ylabel('Last Evaluation')
plt.title('3 Clusters of employees who left')
plt.show()

# Import LabelEncoder
from sklearn import preprocessing
#creating labelEncoder
label = preprocessing.LabelEncoder()
# Convert strings into numbers.
data['salary']=label.fit_transform(data['salary'])
data['dept']=label.fit_transform(data['dept'])

print data

#Spliting data into Feature and label
X=data[['satisfaction_level', 'last_evaluation', 'number_project',
       'average_montly_hours', 'time_spend_company', 'Work_accident',
       'promotion_last_5years', 'dept', 'salary']]

y=data['left']

# Import train_test_split function
from sklearn.model_selection import train_test_split

# section data into training and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=10)  # 70% training and 30% test

#Import Gradient Boosting Classifier model
from sklearn.ensemble import GradientBoostingClassifier

#Create Gradient Boosting Classifier
boost = GradientBoostingClassifier()

#Train the model using the training sets
boost.fit(X_train, y_train)

#Predict the response for test dataset
y_pred = boost.predict(X_test)

# Evaluating Model performance
#Import scikit-learn metrics module for accuracy calculation
from sklearn import metrics
# Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
# Model Precision
print("Precision:",metrics.precision_score(y_test, y_pred))
# Model Recall
print("Recall:",metrics.recall_score(y_test, y_pred))

# using logistic regression

#Logistic Regression Classifier
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
logreg = LogisticRegression()
logreg.fit(X_train, y_train)
# model precision
from sklearn.metrics import accuracy_score
print('Logistic regression accuracy: {:.3f}'.format(accuracy_score(y_test, logreg.predict(X_test))))

#using random forest
from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier()
rf.fit(X_train, y_train)

# model precision for random forest
from sklearn import model_selection
from sklearn.model_selection import cross_val_score
kfold = model_selection.KFold(n_splits=10, random_state=5)
modelCV = RandomForestClassifier()
rating = 'accuracy'
results = model_selection.cross_val_score(modelCV, X_train, y_train, cv=kfold, scoring=rating)
print("10-fold cross validation avg accuracy for Random Forest Classifier: %.3f" % (results.mean()))

# using precision and recall from random forest
from sklearn.metrics import classification_report
print(classification_report(y_test, rf.predict(X_test)))

y_pred = rf.predict(X_test)
from sklearn.metrics import confusion_matrix
import seaborn as sns
forest_pr = metrics.confusion_matrix(y_pred, y_test, [1,0])
sns.heatmap(forest_pr, annot=True, fmt='.2f',xticklabels = ["left", "remained"] , yticklabels = ["left", "remained"] )
plt.ylabel('True class')
plt.xlabel('Pred class')
plt.title('Random Forest')
plt.savefig('rdm_precision')

# ROC Curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve

#ROC for logistic regression
logit_roc_auc = roc_auc_score(y_test, logreg.predict(X_test))
fpr, tpr, thresholds = roc_curve(y_test, logreg.predict_proba(X_test)[:,1])

#ROC for Random Forrest
rf_roc_auc = roc_auc_score(y_test, rf.predict(X_test))
rf_fpr, rf_tpr, rf_thresholds = roc_curve(y_test, rf.predict_proba(X_test)[:,1])

#ROC Curve for Random Forest & Logistic Regression
plt.figure()
plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
plt.plot(rf_fpr, rf_tpr, label='Random Forest (area = %0.2f)' % rf_roc_auc)
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.savefig('ROC')
plt.show()

