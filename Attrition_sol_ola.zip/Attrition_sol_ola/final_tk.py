import pandas as pd
import numpy as np
from pandas import Series, DataFrame
import xlrd
import IPython
from IPython.display import display


# for graphs
from seaborn import set_style
set_style("darkgrid")
import seaborn as sns
import matplotlib.pyplot as plt

excel_file = 'C:\Users\sumbo\Documents\TakenMind-Python-Analytics-Problem-case-study-1-1.xlsx'
# Ingest the data
dta = pd.read_excel(excel_file, sheet_name='Existing employees')
test = pd.read_excel(excel_file, sheet_name='Employees who have left')

# summary and data inspection
print dta.head()
dta.info()
print dta.describe()
print dta.ix[[5, 10, 15]]; print dta[['dept', 'salary']]

# rows and columns
print dta.ix[[5, 10, 15], ["Work_accident", "time_spend_company"]]

# Grouping for visualisation
import datetime

print dta.groupby("salary").dept.describe()
grouper = dta.groupby("dept")     #.ngroup()
print grouper

dept_map = grouper.time_spend_company.unique()
dept_map.sort_index()

with pd.option_context("max_rows", 20):
    print dept_map

dept_map = grouper.time_spend_company.apply(lambda x: x.unique().mean())
dept_map.sort_index()

with pd.option_context("max_rows", 20):
    print dept_map

print dta.groupby("dept").size()
# plotting
ax = dta.groupby("dept").size().plot(kind="barh", figsize=(7, 7))
# setting tick off and placing labels to xtick
# resize y label
ylabel = ax.yaxis.get_label()
ylabel.set_fontsize(23)
# resize x tick label
xlabel = ax.xaxis.get_ticklabels()
# resize y ticks_labels
labels = ax.xaxis.get_ticklabels()
plt.title("Department by Size ")
plt.show()

# Seaborn
import seaborn as sns
#g = sns.factorplot("dept", "average_montly_hours", hue="salary", col="Work_accident", data=dta)
#g.fig.suptitle('Average monthly hours worked by Department', fontsize=25)
#plt.show()

# column assignme
# nt
dta.salary.replace({"high": 2, "medium": 1, "low": 0}, inplace=True)
test.salary.replace({"high": 2, "medium": 1, "low": 0}, inplace=True)

print dta.salary.mean()
print test.salary.mean()

# classification with scikit learn
y = dta.pop("salary")
y_test = test.pop("salary"); dta.info()

# pre processing
from sklearn.preprocessing import LabelBinarizer
print dta.dept.head(15).values

binarizer = LabelBinarizer()
binarizer.fit_transform(dta.dept)
binarizer.classes_

# pre-processing with pandas
X_train = pd.get_dummies(dta)
X_test = pd.get_dummies(test)

# check balance
print X_train.columns.equals(X_test.columns)
print(X_train.shape)
print(X_test.shape)

# check difference
print X_train.columns.difference(X_test)

# preserve order
X_test = X_test[X_train.columns]

# training data for classification
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from os import system
from sklearn.tree import export_graphviz
from graphviz import Source

dtree = DecisionTreeClassifier(random_state=7, max_depth=3)
print dtree.fit(X_train, y)

import pydot
from pandas.compat import StringIO
#tree.export_graphviz(dtree, out_file='tree.dot')
#dotfile = StringIO()
#tree.export_graphviz(dtree, out_file=dotfile)
#pydot.graph_from_dot_data(dotfile.getvalue()).write_png("dtree.png")

# other method using criterion
dtree2 = DecisionTreeClassifier(criterion='entropy', random_state=7)
#dtree2.fit(X_train, y)
#tree.export_graphviz(dtree2, out_file='tree2.dot', feature_names=X_train.columns)
#Source.from_file('tree2.dot')    overfitting the model

# predicting
from sklearn import metrics
print metrics.mean_absolute_error(y_test, dtree.predict(X_test))  #0.4389


#
# using Logistic Regression Classifier
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
logreg = LogisticRegression()
logreg.fit(X_train, y)
LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
          intercept_scaling=1, max_iter=100, multi_class='ovr', n_jobs=1,
          penalty='l2', random_state=None, solver='liblinear', tol=0.0001,
          verbose=0, warm_start=False)

from sklearn.metrics import accuracy_score
print('Logistic regression accuracy: {:.3f}'.format(accuracy_score(y_test, logreg.predict(X_test)))) # 0.434


#For Random Forest
from sklearn import model_selection
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
kfold = model_selection.KFold(n_splits=10, random_state=5)
modelCV = RandomForestClassifier()
scoring = 'accuracy'
results = model_selection.cross_val_score(modelCV, X_train, y, cv=kfold, scoring=scoring)
print("10-fold cross validation average accuracy for Random Forest Classifier: %.3f" % (results.mean())) #0.523


